package com.orderManagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.orderManagement.entity.Product;
import com.orderManagement.entity.User;
import com.orderManagement.exception.OrderNotFoundException;
import com.orderManagement.exception.UserNotFoundException;

public class OrderManagementRepositoryImpl implements IOrderManagementRepository {

    private Connection connection;

    public OrderManagementRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void createOrder(User user, List<Product> products) throws UserNotFoundException {
        try {
            // Insert a new order into the 'Order' table
            String insertOrderQuery = "INSERT INTO Order (userId) VALUES (?)";
            try (PreparedStatement insertOrderStatement = connection.prepareStatement(insertOrderQuery,
                    Statement.RETURN_GENERATED_KEYS)) {
                insertOrderStatement.setInt(1, user.getUserId());
                int affectedRows = insertOrderStatement.executeUpdate();

                if (affectedRows == 0) {
                    throw new SQLException("Creating order failed, no rows affected.");
                }

                // Retrieve the auto-generated orderId
                try (ResultSet generatedKeys = insertOrderStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int orderId = generatedKeys.getInt(1);

                        // Insert order details into the 'Order' table
                        String insertOrderDetailsQuery = "INSERT INTO Order (orderId, productId) VALUES (?, ?)";
                        try (PreparedStatement insertOrderDetailsStatement = connection
                                .prepareStatement(insertOrderDetailsQuery)) {
                            for (Product product : products) {
                                insertOrderDetailsStatement.setInt(1, orderId);
                                insertOrderDetailsStatement.setInt(2, product.getProductId());
                                insertOrderDetailsStatement.addBatch();
                            }
                            insertOrderDetailsStatement.executeBatch();
                        }
                    } else {
                        throw new SQLException("Creating order failed, no ID obtained.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQLException
        }
    }

    @Override
    public void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException {
        try {
            // Check if the user exists
            if (!userExists(userId)) {
                throw new UserNotFoundException("User not found with ID: " + userId);
            }

            // Check if the order exists
            if (!orderExists(orderId)) {
                throw new OrderNotFoundException("Order not found with ID: " + orderId);
            }

            // Delete the order from the 'Order' table
            String deleteOrderQuery = "DELETE FROM Order WHERE orderId = ?";
            try (PreparedStatement deleteOrderStatement = connection.prepareStatement(deleteOrderQuery)) {
                deleteOrderStatement.setInt(1, orderId);
                deleteOrderStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQLException
        }
    }

    private boolean userExists(int userId) throws SQLException {
        String query = "SELECT * FROM User WHERE userId = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    private boolean orderExists(int orderId) throws SQLException {
        String query = "SELECT * FROM Order WHERE orderId = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, orderId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    @Override
    public void createProduct(User adminUser, Product product) throws UserNotFoundException {
        try {
            // Check if the admin user exists
            if (!userExists(adminUser.getUserId())) {
                throw new UserNotFoundException("Admin user not found with ID: " + adminUser.getUserId());
            }

            // Insert a new product into the 'Product' table
            String insertProductQuery = "INSERT INTO Product (productName, description, price, quantityInStock, type) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement insertProductStatement = connection.prepareStatement(insertProductQuery,
                    Statement.RETURN_GENERATED_KEYS)) {
                insertProductStatement.setString(1, product.getProductName());
                insertProductStatement.setString(2, product.getDescription());
                insertProductStatement.setDouble(3, product.getPrice());
                insertProductStatement.setInt(4, product.getQuantityInStock());
                insertProductStatement.setString(5, product.getType());

                insertProductStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQLException
        }
    }

    @Override
    public void createUser(User user) {
        try {
            // Insert a new user into the 'User' table
            String insertUserQuery = "INSERT INTO User (username, password, role) VALUES (?, ?, ?)";
            try (PreparedStatement insertUserStatement = connection.prepareStatement(insertUserQuery)) {
                insertUserStatement.setString(1, user.getUsername());
                insertUserStatement.setString(2, user.getPassword());
                insertUserStatement.setString(3, user.getRole());

                insertUserStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQLException
        }
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        try {
            // Retrieve all products from the 'Product' table
            String query = "SELECT * FROM Product";
            try (Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    // Assuming you have a constructor in the Product class to set attributes
                    Product product = new Product(
                            resultSet.getInt("productId"),
                            resultSet.getString("productName"),
                            resultSet.getString("description"),
                            resultSet.getDouble("price"),
                            resultSet.getInt("quantityInStock"),
                            resultSet.getString("type")
                    );
                    productList.add(product);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQLException
        }
        return productList;
    }

    @Override
    public List<Product> getOrderByUser(User user) throws UserNotFoundException {
        List<Product> orderedProducts = new ArrayList<>();
        try {
            // Check if the user exists
            if (!userExists(user.getUserId())) {
                throw new UserNotFoundException("User not found with ID: " + user.getUserId());
            }

            // Retrieve products ordered by the user from the 'Order' table
            String query = "SELECT p.* FROM Product p " +
                           "JOIN Order o ON p.productId = o.productId " +
                           "WHERE o.userId = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, user.getUserId());
                try (ResultSet resultSet = statement.executeQuery()) {
                    while (resultSet.next()) {
                        // Assuming you have a constructor in the Product class to set attributes
                        Product product = new Product(
                                resultSet.getInt("productId"),
                                resultSet.getString("productName"),
                                resultSet.getString("description"),
                                resultSet.getDouble("price"),
                                resultSet.getInt("quantityInStock"),
                                resultSet.getString("type")
                        );
                        orderedProducts.add(product);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQLException
        }
        return orderedProducts;
    }
}