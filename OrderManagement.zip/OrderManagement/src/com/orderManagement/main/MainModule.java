package com.orderManagement.main;

import java.sql.SQLException;
import java.util.List;

import java.util.Scanner;
import com.orderManagement.dao.IOrderManagementRepository;
import com.orderManagement.dao.OrderManagementRepositoryImpl;
import com.orderManagement.entity.Product;
import com.orderManagement.entity.User;
import com.orderManagement.exception.OrderNotFoundException;
import com.orderManagement.exception.UserNotFoundException;
import com.orderManagement.util.DBUtil;

public class MainModule {

	public static void main(String[] args) {
		try {
			DBUtil.createConnection();
			}catch (ClassNotFoundException e) {
				e.printStackTrace();
			}catch (SQLException e) {
				e.printStackTrace();
			}
		
		
		  	IOrderManagementRepository orderManagementRepository = new OrderManagementRepositoryImpl(null);
	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            System.out.println("Menu:");
	            System.out.println("1. Create User");
	            System.out.println("2. Create Product");
	            System.out.println("3. Cancel Order");
	            System.out.println("4. Get All Products");
	            System.out.println("5. Get Order by User");
	            System.out.println("6. Exit");

	            System.out.print("Enter your choice: ");
	            int choice1 = scanner.nextInt();
	            scanner.nextLine(); 

	            switch (choice1) {
	                case 1:
	                    createUser(orderManagementRepository, scanner);
	                    break;
	                case 2:
	                    createProduct(orderManagementRepository, scanner);
	                    break;
	                case 3:
	                    cancelOrder(orderManagementRepository, scanner);
	                    break;
	                case 4:
	                    getAllProducts(orderManagementRepository);
	                    break;
	                case 5:
	                    getOrderbyUser(orderManagementRepository, scanner);
	                    break;
	                case 6:
	                    System.out.println("Exiting the system. Goodbye!");
	                    System.exit(0);
	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        }
	    }

	    private static void createUser(IOrderManagementRepository orderManagementRepository, Scanner scanner) {
	        System.out.print("Enter user ID: ");
	        int userId = scanner.nextInt();
	        scanner.nextLine(); // Consume the newline character

	        System.out.print("Enter username: ");
	        String username = scanner.nextLine();

	        System.out.print("Enter password: ");
	        String password = scanner.nextLine();

	        System.out.print("Enter role (Admin/User): ");
	        String role = scanner.nextLine();

	        User user = new User(userId, username, password, role);
	        orderManagementRepository.createUser(user);
	        System.out.println("User created successfully.");
	    }

	    private static void createProduct(IOrderManagementRepository orderManagementRepository, Scanner scanner) {
	        System.out.print("Enter admin user ID: ");
	        int adminUserId = scanner.nextInt();
	        scanner.nextLine(); 

	        System.out.print("Enter product ID: ");
	        int productId = scanner.nextInt();
	        scanner.nextLine();
	        
	        System.out.print("Enter product name: ");
	        String productName = scanner.nextLine();

	        System.out.print("Enter description: ");
	        String description = scanner.nextLine();

	        System.out.print("Enter price: ");
	        double price = scanner.nextDouble();
	        scanner.nextLine(); 

	        System.out.print("Enter quantity in stock: ");
	        int quantityInStock = scanner.nextInt();
	        scanner.nextLine(); 

	        System.out.print("Enter type (Electronics/Clothing): ");
	        String type = scanner.nextLine();

	        Product product = new Product(productId, productName, description, price, quantityInStock, type);
	        User adminUser = new User(adminUserId, "", "", "Admin");

	        try {
	            orderManagementRepository.createProduct(adminUser, product);
	            System.out.println("Product created successfully.");
	        } catch (UserNotFoundException e) {
	            System.out.println(e.getMessage());
	        }
	    }


	    private static void cancelOrder(IOrderManagementRepository orderManagementRepository, Scanner scanner) {
	        System.out.print("Enter user ID: ");
	        int userId = scanner.nextInt();
	        scanner.nextLine(); 

	        System.out.print("Enter order ID: ");
	        int orderId = scanner.nextInt();
	        scanner.nextLine(); 

	        try {
	            orderManagementRepository.cancelOrder(userId, orderId);
	            System.out.println("Order canceled successfully.");
	        } catch (UserNotFoundException | OrderNotFoundException e) {
	            System.out.println(e.getMessage());
	        }
	    }

	    private static void getAllProducts(IOrderManagementRepository orderManagementRepository) {
	        List<Product> products = orderManagementRepository.getAllProducts();
	        System.out.println("All Products:");
	        for (Product product : products) {
	            System.out.println(product);
	        }
	    }

	    private static void getOrderbyUser(IOrderManagementRepository orderManagementRepository, Scanner scanner) {
	        System.out.print("Enter user ID: ");
	        int userId = scanner.nextInt();
	        scanner.nextLine(); 

	        try {
	            List<Product> orderedProducts = orderManagementRepository.getOrderByUser(new User(userId, "", "", ""));
	            System.out.println("Products Ordered by User:");
	            for (Product product : orderedProducts) {
	                System.out.println(product);
	            }
	        } catch (UserNotFoundException e) {
	            System.out.println(e.getMessage());
	        }
	    }

	}
